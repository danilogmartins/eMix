﻿using BuscaCEP.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuscaCEP.Domain.Entities
{
    public class Cep : ICep
    {
        public int Id { get; set; }
        public int CEP { get; set; }
        public string Logradouro { get; set; }
        public string Bairro { get; set; }
        public string Localidade { get; set; }
        public string UF { get; set; }
        public long Unidade { get; set; }
        public int IBGE { get; set; }
        public string Guia { get; set; }
    }
}
