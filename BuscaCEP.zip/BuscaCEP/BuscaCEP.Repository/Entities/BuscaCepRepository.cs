﻿using BuscaCEP.Data;
using BuscaCEP.Models;
using BuscaCEP.Repository.Interfaces;
using System;

namespace BuscaCEP.Repository.Entities
{
    public class BuscaCepRepository : IBuscaCEPRepository
    {
        private readonly BancoContext _bancoContext;
        public BuscaCepRepository(BancoContext bancoContext)
        {
            this._bancoContext = bancoContext;
        }

        public CEPModel Gravar( cep)
        {
            this._bancoContext.Ceps.Add(cep);
            this._bancoContext.SaveChanges();
        }
    }
}
