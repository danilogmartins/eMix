﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuscaCEP.Models
{
    public class ListaCEPModel 
    {
        public string UF { get; set; }
        public List<CepModel> Lista { get; set; }
    }
}
