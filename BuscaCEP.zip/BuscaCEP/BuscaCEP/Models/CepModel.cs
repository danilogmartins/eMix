﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace BuscaCEP.Models
{
    public class CepModel
    {
        #region Propriedades encapsuladas

        private string _cep = string.Empty;        
        private string _logradouro = string.Empty;
        private string _bairro = string.Empty;
        private string _localidade = string.Empty;
        private string _UF = string.Empty;

        #endregion

        public CepModel()
        {

        }

        public CepModel(string cep)
        {
            _cep = ValidarCep(cep);
        }


        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("cep")]
        public string Cep
        {
            get => _cep;
            set => _cep = ValidarCep(value);
        }

        public string CepFormatado
        {
            get => $"{_cep.Substring(0, 2)}.{_cep.Substring(2, 3)}-{_cep.Substring(5, 3)}";
        }

        [JsonProperty("logradouro")]
        public string Logradouro
        {
            get => _logradouro;
            set => _logradouro = LimparCaracteresEspeciais(value);
        }

        [JsonProperty("Bairro")]
        public string Bairro
        {
            get => _bairro;
            set => _bairro = LimparCaracteresEspeciais(value);
        }

        [JsonProperty("Localidade")]
        public string Localidade 
        { 
            get => _localidade;
            set => _localidade = LimparCaracteresEspeciais(value);
        }

        [JsonProperty("uf")]
        public string UF
        {
            get => _UF;
            set => _UF = ValidarUF(value);
        }

        [JsonProperty("unidade")]
        public long Unidade { get; set; }

        [JsonProperty("ibge")]
        public int IBGE { get; set; }

        [JsonProperty("gia")]
        public string GIA { get; set; }

        [NotMapped]
        public bool PesquisarBaseDados { get; set; } = false;


        #region Validadores

        private string ValidarCep(string cep)
        {
            const int TAM_CAMPO = 8;
            const string MSG_ERRO = "O CEP informado não é válido.";

            if (string.IsNullOrEmpty(cep) || string.IsNullOrWhiteSpace(cep)) throw new InvalidOperationException(MSG_ERRO);

            cep = cep.Trim().Replace(" ", "").Replace("-", "");

            if (cep.Length != TAM_CAMPO) throw new Exception(MSG_ERRO);

            return cep;
        }

        private string ValidarUF(string uf)
        {
            const int TAM_CAMPO = 2;
            const string MSG_ERRO = "A UF informada não e válida.";
            
            if (string.IsNullOrEmpty(uf) || string.IsNullOrWhiteSpace(uf)) throw new InvalidOperationException(MSG_ERRO);
            if (uf.Trim().Length != TAM_CAMPO) throw new Exception(MSG_ERRO);

            return uf.Trim().ToUpper();
        }

        private string LimparCaracteresEspeciais(string value)
        {
            const string CARACTERES = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890áéíóúàèìòùâêîôûãõçÁÉÍÓÚÀÈÌÒÙÂÊÎÔÛÃÕÇ ";
            StringBuilder strRetorno = new StringBuilder();
            foreach (var c in value)
            {
                if (CARACTERES.IndexOf(c) > -1)
                {
                    strRetorno.Append(c);
                }
            }
            return strRetorno.ToString();
        }

        #endregion

    }
}
