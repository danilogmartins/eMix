﻿using BuscaCEP.Models;
using System.Collections.Generic;

namespace BuscaCEP.Repository
{
    public interface ICepRepository
    {
        CepModel Abrir(string cep);
        CepModel Gravar(CepModel cep);
        List<CepModel> ListarTodos();
        List<CepModel> ListarPorUF(string uf);
    }
}
