﻿using BuscaCEP.Data;
using BuscaCEP.Models;
using System.Collections.Generic;
using System.Linq;

namespace BuscaCEP.Repository
{
    public class CepRepository : ICepRepository
    {
        private readonly BancoContext _bancoContext;
        public CepRepository(BancoContext bancoContext)
        {
            this._bancoContext = bancoContext;
        }

        public CepModel Abrir(string cep)
        {
            return _bancoContext.Cep.Where(x => x.Cep == cep.ToUpper()).FirstOrDefault();
        }

        public CepModel Gravar(CepModel cep)
        {
            if(ValidarDados(cep))
            {
                CepModel cepModelTemp = Abrir(cep.Cep);
                if (cepModelTemp == null)
                {
                    this._bancoContext.Cep.Add(cep);
                    this._bancoContext.SaveChanges();
                    return cep;
                }
                else
                {
                    return cepModelTemp;
                }
            }
            return null;
        }

        public List<CepModel> ListarTodos()
        {
            return this._bancoContext.Cep.ToList();
        }

        public List<CepModel> ListarPorUF(string uf)
        {
            return this._bancoContext.Cep.Where(x => x.UF == uf.ToUpper()).ToList();
        }

        private bool ValidarDados(CepModel cepModel)
        {
            if (cepModel == null) return false;
            if ((string.IsNullOrEmpty(cepModel.Cep) || string.IsNullOrWhiteSpace(cepModel.Cep)) || cepModel.Cep.Length != 8) return false;
            if (string.IsNullOrEmpty(cepModel.Localidade) || string.IsNullOrWhiteSpace(cepModel.Localidade)) return false;

            return true;
        }
    }
}
