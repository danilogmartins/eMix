﻿using BuscaCEP.Models;
using BuscaCEP.Repository;
using Microsoft.AspNetCore.Mvc;

namespace BuscaCEP.Controllers
{
    public class ListarCEPController : Controller
    {
        private readonly ICepRepository _cepRepository;
        
        public ListarCEPController(ICepRepository cepRepository)
        {
            this._cepRepository = cepRepository;            
        }

        public IActionResult Index()
        {
            return View();
        }        

        public IActionResult Listar(ListaCEPModel listaCep)
        {
            ListaCEPModel listResult = new ListaCEPModel();
            if(string.IsNullOrEmpty(listaCep.UF))
            {
                listResult.Lista = _cepRepository.ListarTodos();
            }
            else
            {
                listResult.Lista = _cepRepository.ListarPorUF(listaCep.UF);
            }
            listResult.UF = listaCep.UF;
            return View("Index", listResult);
        }        
    }
}
