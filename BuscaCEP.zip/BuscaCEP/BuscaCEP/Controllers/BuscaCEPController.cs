﻿using BuscaCEP.Models;
using BuscaCEP.Repository;
using BuscaCEP.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BuscaCEP.Controllers
{
    public class BuscaCEPController : Controller
    {
        private readonly ICepRepository _cepRepository;
        private readonly IBuscaCepService _buscaCepService;
        public BuscaCEPController(ICepRepository cepRepository, IBuscaCepService buscaCepService)
        {
            this._cepRepository = cepRepository;
            this._buscaCepService = buscaCepService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Pesquisar(CepModel cepModel)
        {            
            CepModel result;
            if (cepModel.PesquisarBaseDados)
            {
                bool pesquisarBancoDados = cepModel.PesquisarBaseDados;
                result = PesquisarBanco(cepModel);
                result.PesquisarBaseDados = pesquisarBancoDados;
            }
            else
            {
                result = PesquisarWeb(cepModel);
                
                if(result != null)
                {
                    _cepRepository.Gravar(result);                    
                }
            }
            return View("Index", result ?? new CepModel());            
        }

        [HttpPost]
        public IActionResult Gravar(CepModel cepModel)
        {            
            var result = this._cepRepository.Gravar(cepModel);
            return View();
        }

        private CepModel PesquisarWeb(CepModel cepModel)
        {
            //BuscaCepService service = new BuscaCepService();
            var resultWeb = _buscaCepService.PesquisarCepWeb(cepModel.Cep.ToString());
            return resultWeb;
        }

        private CepModel PesquisarBanco(CepModel cepModel)
        {
            var resultBanco = _cepRepository.Abrir(cepModel.Cep);
            return resultBanco;
        }
    }
}
