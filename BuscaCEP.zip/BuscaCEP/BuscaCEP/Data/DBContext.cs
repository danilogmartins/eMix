﻿using BuscaCEP.Models;
using Microsoft.EntityFrameworkCore;


namespace BuscaCEP.Data
{
    public class BancoContext : DbContext
    {
        public BancoContext(DbContextOptions<BancoContext> options): base(options)
        {
        }

        public DbSet<CepModel> Cep { get; set; }
    }
}
