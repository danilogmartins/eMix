﻿using BuscaCEP.Models;
using BuscaCEP.Services.Interfaces;
using Newtonsoft.Json;
using System;
using System.Net;


namespace BuscaCEP.Services
{
    public class BuscaCepService : IBuscaCepService
    {
        public CepModel PesquisarCepWeb(string cep)
        {
            try
            {
                CepModel cepModel = new CepModel(cep);
                
                using (WebClient client = new WebClient())
                {
                    string result = client.DownloadString($"https://viacep.com.br/ws/{cepModel.Cep}/json/");
                    return JsonConvert.DeserializeObject<CepModel>(result);
                }
            }
            catch (Exception)
            {
                return null;
            } 
        }
    }
}
